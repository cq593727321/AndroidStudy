package com.function;

import com.demo.utils.UhfDev;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class MyReceiver extends BroadcastReceiver {
	public static final String ActionOffScreen = "android.intent.action.SCREEN_OFF";// 屏幕被关闭之后的广播
	public static final String ActionOnScreen = "android.intent.action.SCREEN_ON";// 屏幕被打开之后的广播
	private static MyReceiver m_receiver = new MyReceiver();
	public static MyReceiver getInstance() {
		return m_receiver;
	}
	
	// region 待机监控
		public void StartMoniter(Context context) {
			IntentFilter filter = new IntentFilter();
			// filter.addAction(ActionCloseSystem);
			filter.addAction(ActionOffScreen);
			filter.addAction(ActionOnScreen);
			filter.setPriority(Integer.MAX_VALUE);
			// 动态注册BroadcastReceiver
			context.registerReceiver(this, filter);
		}

		public void StopMoniter(Context context) {
			context.unregisterReceiver(this);
		}
		// endregion 待机监控
		
	private void Sleep(int times) {
		try {
			Thread.sleep(times);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		UhfDev dev = UhfDev.getInstance();
		if (ActionOffScreen == intent.getAction()) {
			dev.PauseInventory();
			Sleep(500);
			dev.Close();
		} else if (ActionOnScreen == intent.getAction()) {
			dev.ReConnect();
		}
	}
}