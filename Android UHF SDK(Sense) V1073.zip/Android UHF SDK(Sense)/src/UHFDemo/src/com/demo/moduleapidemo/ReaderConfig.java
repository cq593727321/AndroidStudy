//ReaderConfig.java：配置页面
package com.demo.moduleapidemo;

import com.demo.utils.UhfDev;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

/**
 * 设置功率，调节距离
 * 
 * @author Administrator
 * 
 */
public class ReaderConfig extends Activity implements OnClickListener {
	private ArrayAdapter<String> arradp_pow, arrdp_Region, arrdp_invmo,
			arrdp_customrd;
	Spinner spinner_antpow, spinner_Region, spinner_invmode, spinner_customrd;

	// button_getgen2q, button_setgen2q,
	Button button_getantpower, button_setantpower, button_getRegion,
			button_setRegion, button_invmodeget, button_invmodeset,
			button_GetReaderID, button_GetPortLoss, button_customrdset,
			button_customrdget;
	String[] spipow = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
			"11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
			"22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32",
			"33", };// 运行时添加
	String[] spiRegion = { "FCC", "ETSI", "CHN2",  "CHN1","Korea", "Japan", };// 运行时添加

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.reader_config);
		super.onCreate(savedInstanceState);
		initView();
		
		if(GetPower(false)) {
			GetRegion(false);
			GetReaderID(false);
		}
		if(0==getResources().getString(R.string.show_append).compareTo("0")) {
			LinearLayout linear_InvMode =(LinearLayout)findViewById(R.id.linear_InvMode);
			LinearLayout linear_ReaderID =(LinearLayout)findViewById(R.id.linear_ReaderID);
			LinearLayout linear_PortLoss =(LinearLayout)findViewById(R.id.linear_PortLoss);
			LinearLayout linear_customrdMode =(LinearLayout)findViewById(R.id.linear_customrdMode);
			linear_InvMode.setVisibility(View.INVISIBLE);
			//linear_ReaderID.setVisibility(View.INVISIBLE);
			linear_PortLoss.setVisibility(View.INVISIBLE);
			linear_customrdMode.setVisibility(View.INVISIBLE);
		}
		
	}

	private void initView() {
		String[] spicustomrd = getResources().getStringArray(R.array.readType_array);// { "标准模式", "自动触发读卡", };// 运行时添加
		String[] spinvmo =  getResources().getStringArray(R.array.tagNum_array);  //{ "少量模式", "中量模式", "大量模式" };

		// 功率
		spinner_antpow = (Spinner) findViewById(R.id.spinner_antpow);
		arradp_pow = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, spipow);
		arradp_pow
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_antpow.setAdapter(arradp_pow);

		// Region
		spinner_Region = (Spinner) findViewById(R.id.spinner_Region);
		arrdp_Region = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, spiRegion);
		arrdp_Region
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_Region.setAdapter(arrdp_Region);

		// 盘存模式
		spinner_invmode = (Spinner) findViewById(R.id.spinner_invmode);
		arrdp_invmo = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, spinvmo);
		arrdp_invmo
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_invmode.setAdapter(arrdp_invmo);

		// 定制模式
		spinner_customrd = (Spinner) findViewById(R.id.spinner_customrd);
		arrdp_customrd = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, spicustomrd);
		arrdp_customrd
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_customrd.setAdapter(arrdp_customrd);
		
		// 按钮
		button_getantpower = (Button) findViewById(R.id.button_antpowget);
		button_setantpower = (Button) findViewById(R.id.button_antpowset);
		button_getRegion = (Button) findViewById(R.id.button_Regionget);
		button_setRegion = (Button) findViewById(R.id.button_Regionset);
		button_invmodeget = (Button) findViewById(R.id.button_invmodeget);
		button_invmodeset = (Button) findViewById(R.id.button_invmodeset);
		button_customrdget = (Button) findViewById(R.id.button_customrdget);
		button_customrdset = (Button) findViewById(R.id.button_customrdset);
		button_GetReaderID = (Button) findViewById(R.id.button_GetReaderID);
		button_GetPortLoss = (Button) findViewById(R.id.button_GetPortLoss);

		button_getantpower.setOnClickListener(this);
		button_setantpower.setOnClickListener(this);
		button_getRegion.setOnClickListener(this);
		button_setRegion.setOnClickListener(this);
		button_invmodeget.setOnClickListener(this);
		button_invmodeset.setOnClickListener(this);
		button_customrdget.setOnClickListener(this);
		button_customrdset.setOnClickListener(this);
		button_GetReaderID.setOnClickListener(this);
		button_GetPortLoss.setOnClickListener(this);
	}

	// 查找功率
	private boolean GetPower(boolean bShowInfo) {
		int iPower = -1;
		try {
			UhfDev dev = UhfDev.getInstance();
			iPower = dev.GetPower();
			String szInfo = getString(R.string.Get)+getString(R.string.fail);
			if (iPower >= 0) {
				spinner_antpow.setSelection(iPower);
				szInfo = getString(R.string.Get) + getString(R.string.succ);
			}
			if (bShowInfo)
				Toast.makeText(ReaderConfig.this, szInfo, Toast.LENGTH_SHORT)
						.show();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(ReaderConfig.this, getString(R.string.fail)+":" + e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}
		return  (iPower >= 0);
	}
// 查找Region
		private void GetRegion(boolean bShowInfo) {
			try {
				UhfDev dev = UhfDev.getInstance();
				int iPower = dev.GetRegion();
				String szInfo =getString(R.string.Get)+getString(R.string.fail);
				if (iPower >= 0) {
					spinner_Region.setSelection(iPower);
					szInfo = getString(R.string.Get)+getString(R.string.succ);
				}
				if (bShowInfo)
					Toast.makeText(ReaderConfig.this, szInfo, Toast.LENGTH_SHORT)
							.show();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Toast.makeText(ReaderConfig.this, getString(R.string.fail)+":" + e.getMessage(),
						Toast.LENGTH_SHORT).show();
			}
		}
	// 查找模式
	private void GetReaderMode(boolean bShowInfo) {
		try {
			UhfDev dev = UhfDev.getInstance();
			byte []invMode = new byte[2];
			byte []flag = new byte[2];
			String szInfo = getString(R.string.Get)+getString(R.string.fail);
			if (dev.GetReadMode(invMode, flag)) {
				spinner_invmode.setSelection(invMode[0]);
				szInfo = getString(R.string.Get)+getString(R.string.succ);
			}
			if (bShowInfo)
				Toast.makeText(ReaderConfig.this, szInfo, Toast.LENGTH_SHORT)
						.show();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(ReaderConfig.this, getString(R.string.fail)+":" + e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}
	}
	
	private void GetCustomReaderMode(boolean bShowInfo) {
		try {
			UhfDev dev = UhfDev.getInstance();
			int bReaderMode = dev.GetCustomReaderMode();
			String szInfo = getString(R.string.Get)+getString(R.string.fail);
			if (bReaderMode < 0xFF) {
				spinner_customrd.setSelection(bReaderMode);
				szInfo = getString(R.string.Get)+getString(R.string.succ);
			}
			if (bShowInfo)
				Toast.makeText(ReaderConfig.this, szInfo, Toast.LENGTH_SHORT)
						.show();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(ReaderConfig.this, getString(R.string.fail)+":" + e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}
	}

	//查询序号
	private boolean GetReaderID(boolean bShowInfo) {
		boolean bSucc =  false;
		try {
			String szReaderID = UhfDev.getInstance().GetReaderID();
			bSucc = (""!=szReaderID);
			if (bShowInfo)
				Toast.makeText(ReaderConfig.this,getString(R.string.getReaderID)+
						(bSucc ? getString(R.string.succ) :getString(R.string.fail)), Toast.LENGTH_SHORT)
						.show();
			EditText etReaderID= (EditText) findViewById(R.id.editText_ReaderID);
			etReaderID.setText(szReaderID);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(ReaderConfig.this, getString(R.string.fail)+":" + e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}
		return bSucc;
	}

	// 查询序号
	private boolean GetPortLoss() {
		boolean bSucc = false;
		try {
			int iPortLoss = UhfDev.getInstance().GetPortLoss();
			bSucc = (iPortLoss >= -100);
			Toast.makeText(ReaderConfig.this,getString(R.string.PortLoss)+
					(bSucc ? getString(R.string.succ) :getString(R.string.fail)),
					Toast.LENGTH_SHORT).show();
			EditText etPortLoss = (EditText) findViewById(R.id.editText_PortLoss);
			etPortLoss.setText(String.format("%d", iPortLoss));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(ReaderConfig.this, getString(R.string.fail)+":" + e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}
		return bSucc;
	}

	@Override
	public void onClick(View v) {
		try {
			UhfDev dev = UhfDev.getInstance();
			switch (v.getId()) {
			case R.id.button_antpowget: // 功率查询
				GetPower(true);
				break;
			case R.id.button_antpowset: { // 功率设置
				int power = spinner_antpow.getSelectedItemPosition();
				boolean bSucc = dev.SetPower(power);
				Toast.makeText(ReaderConfig.this,getString(R.string.setPower)+
						(bSucc ? getString(R.string.succ) :getString(R.string.fail)),
						Toast.LENGTH_SHORT).show();
			}
				break;
			case R.id.button_Regionget: 
				GetRegion(true);
			break;
			case R.id.button_Regionset: {
				int region = spinner_Region.getSelectedItemPosition();
				boolean bSucc = dev.SetRegion(region);
				Toast.makeText(ReaderConfig.this,
						getString(R.string.setRegion)+
						(bSucc ? getString(R.string.succ) :getString(R.string.fail)), Toast.LENGTH_SHORT)
						.show();
			}
			break;
			case R.id.button_invmodeget: // 模式查询
				GetReaderMode(true);
				break;
			case R.id.button_invmodeset: { // 模式设置
				boolean bSucc = dev.SetReadMode(
						(byte) spinner_invmode.getSelectedItemPosition(),
						(byte) 0);
				Toast.makeText(ReaderConfig.this,
						getString(R.string.setInvMode)+
						(bSucc ? getString(R.string.succ) :getString(R.string.fail)), Toast.LENGTH_SHORT)
						.show();
			}
				break;
			case R.id.button_customrdget: // 模式查询
				GetCustomReaderMode(true);
				break;
			case R.id.button_customrdset: { // 模式设置
				byte bReaderMode = (byte) spinner_customrd.getSelectedItemPosition();
				if(0!=bReaderMode)
					bReaderMode = 0x13;
				boolean bSucc = dev.SetCustomReaderMode(bReaderMode);
				Toast.makeText(ReaderConfig.this,
						getString(R.string.setRegion)+
						(bSucc ? getString(R.string.succ) :getString(R.string.fail)), Toast.LENGTH_SHORT)
						.show();
			}
				break;
			case R.id.button_GetReaderID: // 查询序号
				GetReaderID(true);
				break;
			case R.id.button_GetPortLoss:	//回波损耗
				GetPortLoss();
				break;
			default:
				break;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(ReaderConfig.this, getString(R.string.fail)+":" + e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}
	}
}
