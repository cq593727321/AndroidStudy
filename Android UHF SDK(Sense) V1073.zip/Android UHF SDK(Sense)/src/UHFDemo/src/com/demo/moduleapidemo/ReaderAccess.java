//ReaderAccess.java：标签读写页面
package com.demo.moduleapidemo;

import java.util.List;

import com.RFID.TAGINFO;
import com.demo.utils.SoundUtil;
import com.demo.utils.UhfDev;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class ReaderAccess extends Activity implements View.OnClickListener {
	private ArrayAdapter<String> arradp_bank,arradp_lockbank;
	Spinner spinner_bank,spinner_lockbank;
	Button button_read,button_write,button_inventory,button_getmask,button_lock,button_unlock;
	String[] spibank = { "Reserved", "EPC", "TID", "User", };// 运行时添加
	String[] spilockbank = {"User", "TID", "EPC", "AccessPwd","KillPwd",  };// 运行时添加
	EditText etaddr,etcount,etdata,etEPC,etAccessPwd;
	CheckBox cbEPC;
	UhfDev m_UHFDev = UhfDev.getInstance();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.reader_access);
		super.onCreate(savedInstanceState);
		initView();
	}

	private void initView() {
		// 块区
		spinner_bank = (Spinner) findViewById(R.id.spinner_bank);
		arradp_bank = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, spibank);
		arradp_bank
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_bank.setAdapter(arradp_bank);
		spinner_bank.setSelection(1);
		
		spinner_lockbank = (Spinner) findViewById(R.id.spinner_lockbank);
		arradp_lockbank = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, spilockbank);
		arradp_lockbank
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner_lockbank.setAdapter(arradp_lockbank);
		spinner_lockbank.setSelection(0);

		//选项
		etaddr=(EditText)findViewById(R.id.editText_startaddr); etaddr.setText("2");
		etcount=(EditText)findViewById(R.id.editText_opcount);etcount.setText("2");
		etdata=(EditText)findViewById(R.id.editText_data);
		etEPC = (EditText)findViewById(R.id.editText_EPC);
		etAccessPwd = (EditText)findViewById(R.id.editText_lockpwd);
		
		cbEPC = (CheckBox)findViewById(R.id.cbEPC);
		cbEPC.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
            	etEPC.setEnabled(!cbEPC.isChecked());
            	SetAccessEPCMask();
			}
        });
		
		// 按钮
		button_getmask = (Button)findViewById(R.id.button_getmask);
		button_inventory=(Button)findViewById(R.id.button_inventory);
		button_read = (Button) findViewById(R.id.button_read);
		button_write = (Button) findViewById(R.id.button_write);
		button_lock = (Button)findViewById(R.id.button_lock);
		button_unlock = (Button)findViewById(R.id.button_unlock);
		button_getmask.setOnClickListener(this);
		button_inventory.setOnClickListener(this);
		button_read.setOnClickListener(this);
		button_write.setOnClickListener(this);
		button_lock.setOnClickListener(this);
		button_unlock.setOnClickListener(this);
	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
	
	//设置匹配
	private boolean SetAccessEPCMask() {
		byte bMode = (byte)(cbEPC.isChecked()?1:0);
		String szEPC  = etEPC.getText().toString().replace(" ","");
		byte epcLen = (byte)(szEPC.length()/2);
		byte[] bEPC = new byte[epcLen];
		
		m_UHFDev.reader.Str2HexArray(szEPC, szEPC.length(), bEPC);
		boolean bSucc = m_UHFDev.reader.SetAccessEPCMask(bMode, epcLen, bEPC);
		if(!bSucc)
			Toast.makeText(ReaderAccess.this, getString(R.string.setFilter)+getString(R.string.fail), Toast.LENGTH_SHORT).show();
		return bSucc;
	}
	//查询匹配
	private boolean GetAccessMask() {
		etEPC.setText("");
		byte []bMode = new byte[2];
		byte [] bEPCLen = new byte[2];
		byte[] bEPC = new byte[0xFF];
		boolean bSucc = m_UHFDev.reader.GetAccessEPCMask(bMode, bEPCLen, bEPC);
		if(!bSucc) {
			Toast.makeText(ReaderAccess.this,getString(R.string.getFilter)+getString(R.string.fail), Toast.LENGTH_SHORT).show();
			return false;
		}
		cbEPC.setChecked(1==bMode[0]);
		String szEPC = m_UHFDev.reader.HexArray2Str(bEPC, bEPCLen[0]);
		etEPC.setText(szEPC);
		Toast.makeText(ReaderAccess.this, getString(R.string.getFilter)+getString(R.string.succ), Toast.LENGTH_SHORT).show();
		return true;
	}
	//盘存标签
	private void InventoryTag() {
		etEPC.setText("");
		List<TAGINFO> lstTag = m_UHFDev.reader.Inventory(1000);
		String szInfo = getString(R.string.Inventory)+getString(R.string.fail);
		if((null!=lstTag) && (lstTag.size()>0)) {
			TAGINFO info =lstTag.get(0);
			String szEPC = m_UHFDev.reader.HexArray2Str(info.EpcId);
			etEPC.setText(szEPC);
			szInfo = "盘存标签成功";
			SoundUtil.play(R.raw.pegconn, 0);
		}
		Toast.makeText(ReaderAccess.this, szInfo, Toast.LENGTH_SHORT)
				.show();
	}
	
	//锁标签
	private void LockTag(boolean bLock) {
		byte lockbank =(byte) (spinner_lockbank.getSelectedItemPosition()+1);
		String szData = etAccessPwd.getText().toString().replace(" ", "");
		while(szData.length()<8)
			szData += "0";
		byte[] AccessPwd = new byte[4];
		m_UHFDev.reader.Str2HexArray(szData, 8, AccessPwd);
		
		String szOption = bLock?getString(R.string.lockTag):getString(R.string.unlockTag);
		boolean bSucc = m_UHFDev.reader.LockTagData(lockbank, (byte)(bLock?1:0), AccessPwd, (short) 2000);
		Toast.makeText(ReaderAccess.this,szOption+(bSucc?getString(R.string.succ):getString(R.string.fail)), Toast.LENGTH_SHORT).show();
	}
	@Override
	public void onClick(View v) {
		try {
			byte bank =(byte) spinner_bank.getSelectedItemPosition();
			int address =  Integer.valueOf(etaddr.getText().toString());
			int blkcnt =  Integer.valueOf(etcount.getText().toString());
			if(blkcnt<1){
				Toast.makeText(ReaderAccess.this,getString(R.string.inputLength), Toast.LENGTH_SHORT).show();
				return;
			}
			byte[] accesspassword = new byte[]{0x00,0x00,0x00,0x00};
			short timeout = 2000;
			
			switch (v.getId()) {
			case R.id.button_getmask: //查询匹配
				GetAccessMask();
				break;
			case R.id.button_inventory: //盘存标签
				InventoryTag();
			break;
			case R.id.button_read: { // 读标签
				byte[] data = new byte[blkcnt*2];
				boolean bSucc = m_UHFDev.reader.ReadTagData(bank, address, blkcnt, data, accesspassword, timeout);
				String szInfo = getString(R.string.ReadTag)+getString(R.string.fail);
				if (bSucc) {
					String szData = m_UHFDev.reader.HexArray2Str(data);
					etdata.setText(szData);
					szInfo = getString(R.string.ReadTag)+getString(R.string.succ);
					SoundUtil.play(R.raw.pegconn, 0);
				}
				Toast.makeText(ReaderAccess.this, szInfo, Toast.LENGTH_SHORT)
						.show();
			}
				break;
			case R.id.button_write: { // 写标签
				String szData = etdata.getText().toString();
				while(szData.length()<blkcnt*4)
					szData += "0";
				byte[] data = new byte[blkcnt*2];
				m_UHFDev.reader.Str2HexArray(szData, blkcnt*4, data);
				boolean bSucc = m_UHFDev.reader.WriteTagData(bank, address, data, data.length/2,accesspassword, timeout);
				String szInfo =getString(R.string.WriteTag)+
						(bSucc?getString(R.string.succ):getString(R.string.fail));
				if(bSucc)
					SoundUtil.play(R.raw.pegconn, 0);
				Toast.makeText(ReaderAccess.this, szInfo, Toast.LENGTH_SHORT)
						.show();
			}
				break;
			case R.id.button_lock: //锁
				LockTag(true);
				break;
			case R.id.button_unlock: //解锁
				LockTag(false);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(ReaderAccess.this,getString(R.string.fail)+ ":" + e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}
	}
}
