package com.demo.moduleapidemo;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.util.Log;
import android.widget.Toast;

import com.demo.utils.FileManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
/**
 * Created by Administrator on 2016/12/7.
 */
public class DataManage {
    private static DataManage mDataManage = new DataManage();
    public static DataManage getInstance() {
        return mDataManage;
    }
    private String szHeadLine = EPC.getHeaderString();
    private Context mContext = null;
    public List<EPC> m_lstAllEPC = new ArrayList<EPC>();


    //region 导出数据
    private String m_szDir = android.os.Environment.getExternalStorageDirectory().toString()+"/盘存日志";
    private String m_szDirEx = android.os.Environment.getExternalStorageDirectory().toString()+"/盘存日志备份";
    //获取实时保存文件
    public String getRealSaveFile() {
        String fileName =m_szDir+"/实时保存.txt" ;
        return fileName;
    }
    public String getExternSaveFile() {
        String fileName =m_szDirEx+"/实时保存备份.txt" ;
        return fileName;
    }
    public void exportAllDataRealTimeExit() {
        SimpleDateFormat formatter = new SimpleDateFormat("退出保存备份");
        Date curDate = new Date(System.currentTimeMillis());//获取当前时间
        String fileName =m_szDir+"/"+formatter.format(curDate)+".txt" ;
        WriteAllToFile(m_szDir, fileName,m_lstAllEPC);
    }
    //获取显示内容
    private String GetShowInfo(EPC info) {
        return info.getValueString();
    }
    //导出数据
    public void exportData() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd HHmmss导出");
        Date curDate = new Date(System.currentTimeMillis());//获取当前时间
        String fileName =m_szDir+"/"+formatter.format(curDate)+".txt" ;
        boolean bSucc = WriteAllToFile(m_szDir, fileName);
        Toast.makeText(mContext,bSucc?("导出文件成功:"+fileName):"导出文件失败",
                Toast.LENGTH_SHORT).show();
    }
    //实时增加数据
    public boolean exportDataRealTime(EPC info) {
        boolean bSucc = writeOneRecordToFile(m_szDir, getRealSaveFile(),info);
        writeOneRecordToFile(m_szDirEx, getExternSaveFile(),info);    //附加保存文件
        return bSucc;
    }
    //实时保存所有数据
    public void exportAllDataRealTime(Context mContext) {
        String fileName = getRealSaveFile();
        boolean bSucc = WriteAllToFile(m_szDir, fileName,m_lstAllEPC);
        //Toast.makeText(MainActivity.this,bSucc?("导出文件成功:"+fileName):"导出文件失败",
        //        Toast.LENGTH_SHORT).show();
    }
    // 将所有字符串写入到文本文件中
    public boolean WriteAllToFile( String szFolder, String fileName) {
        //生成文件夹之后，再生成文件，不然会出错
        FileManager.makeFilePath(szFolder, fileName);
        FileManager.fileScan(mContext, fileName);

        // 每次写入时，都换行写
        try {
        	File file = new File(fileName);
            RandomAccessFile raf = new RandomAccessFile(file, "rwd");
            raf.seek(file.length());
            if(file.length()<=0)
                raf.write(szHeadLine.getBytes());

            for (int index = 0; index < m_lstAllEPC.size(); index++) {
                EPC info = m_lstAllEPC.get(index);
                String strContent = GetShowInfo(info);
                raf.write(strContent.getBytes());
            }
            raf.close();
            return true;
        } catch (Exception e) {
            Log.e("TestFile", "Error on write File:" + e);
        }
        return false;
    }

    //重写所有数据
    public boolean WriteAllToFile(String szFolder,
    		String fileName,List<EPC> lstEPC) {
        //生成文件夹之后，再生成文件，不然会出错
        FileManager.makeFilePath(szFolder, fileName);
        FileManager.fileScan(mContext, fileName);

        // 每次写入时，都换行写
        try {
        	 File file = new File(fileName);
             RandomAccessFile raf = new RandomAccessFile(file, "rwd");
             raf.seek(file.length());
             if(file.length()<=0)
                 raf.write(szHeadLine.getBytes());
            for(int index=0;index<lstEPC.size();index++) {
                EPC info =  lstEPC.get(index);
                String strContent = GetShowInfo(info);
                raf.write(strContent.getBytes());//out.write(strContent.getBytes());
            }
            raf.close();
            return true;
        } catch (Exception e) {
            Log.e("TestFile", "Error on write File:" + e);
        }
        return false;
    }

    private String removeDot(String szInfo) {
        if(szInfo.startsWith("'"))
            szInfo = szInfo.substring(1);
        return szInfo;
    }
   
    public void AddOneAssetsInfo(EPC assetsInfo){
    	if(m_lstAllEPC.contains(assetsInfo.getEpc()))
    		return;

    	m_lstAllEPC.add(assetsInfo);
    	lockSave.lock();
    	m_lstSaveEPC.add(assetsInfo);
        //exportDataRealTime(mContext,assetsInfo);
        lockSave.unlock();
    }

    // 将一行字符串写入到文本文件中
    public boolean writeOneRecordToFile(String szFolder, String fileName,EPC info) {
        //生成文件夹之后，再生成文件，不然会出错
        FileManager.makeFilePath(szFolder, fileName);
        FileManager.fileScan(mContext, fileName);

        // 每次写入时，都换行写
        try {
            File file = new File(fileName);
            RandomAccessFile raf = new RandomAccessFile(file, "rwd");
            raf.seek(file.length());
            if(file.length()<=0)
                raf.write(szHeadLine.getBytes());
            String strContent = GetShowInfo(info);
            raf.write(strContent.getBytes());
            raf.close();
            FlushFile(fileName);
            return true;
        } catch (Exception e) {
            Log.e("TestFile", "Error on write File:" + e);
        }
        return false;
    }

    private void FlushFile(String szFile) {
        try {
            Runtime runtime = Runtime.getRuntime();
            Process proc = runtime.exec("fsync " + szFile);
        }catch (IOException ex) {
            ;
        }
    }

    //删除实时数据
    public boolean DeleteRlDate() {
        File file = new File(getRealSaveFile());
        if(file.exists()){
            file.delete();
            return true;
        }
        return false;
    }
    //endregion 导出数据
    
    
 // region 声音线程
 	private Thread thSave = null; // 声音线程句柄
 	private boolean runSaveTh = false; // 声音线程开关
 	private boolean bSavedPlay = false; // 声音
 	private List<EPC> m_lstSaveEPC = new ArrayList<EPC>();
 	private Lock lockSave = new ReentrantLock();

 	// 启动声音线程
 	public void StartSaveThread(Context context) {
 		mContext = context;
 		if (null == thSave) {
 			runSaveTh = true;
 			thSave = new Thread(SoundThread);
 			thSave.start();
 		}
 	}

 	// 停止声音线程
 	public void StopSaveThread() {

 		try {
 			if (null != thSave) {
 				bSavedPlay = false;
 				runSaveTh = false;
 				thSave.join(2000);
 				thSave.interrupt();
 				thSave = null;
 			}
 		} catch (InterruptedException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
 	}

 	Runnable SoundThread = new Runnable() {
 		@Override
 		public void run() {
 			int iSoundTimes = 0;
 			String fileName = getRealSaveFile();
 			String fileNameEx = getExternSaveFile();
 			while (runSaveTh) {
 				try {
 					if (m_lstSaveEPC.size()>0) {
 						lockSave.lock();
 						WriteAllToFile(m_szDir, fileName,m_lstSaveEPC);
 						WriteAllToFile(m_szDirEx, fileNameEx,m_lstSaveEPC);
 						m_lstSaveEPC.clear();
 						lockSave.unlock();
 					}
 					Thread.sleep(10);
 				} catch (InterruptedException e) {
 					// TODO Auto-generated catch block
 					e.printStackTrace();
 				}
 			}
 		}
 	};
 	// endregion
}
