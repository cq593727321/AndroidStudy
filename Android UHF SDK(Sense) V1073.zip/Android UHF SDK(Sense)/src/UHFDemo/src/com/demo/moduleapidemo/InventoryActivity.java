//InventoryActivity.java：盘存页面
package com.demo.moduleapidemo;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.RFID.TAGINFO;
import com.RFID.RFIDReader.InvCallBack;
import com.demo.utils.*;
import com.function.PowerMoniter;

public class InventoryActivity extends Activity implements OnClickListener,
		OnItemClickListener, OnCheckedChangeListener {

	private Button buttonReset, buttonStart;
	private TextView textViewSuccReadNum, textViewTagReadNum,
			textViewReadTimeNum;
	private ListView listViewData;

	private ArrayList<EPC> listEPC;
	private ArrayList<Map<String, Object>> listMap = new ArrayList<Map<String, Object>>();

	private int succSum = 0;
	private int tagSum = 0;
	private UhfDev mDev = UhfDev.getInstance();
	private Date dtStart; // 开始时间
	private CheckBox cbBackTag = null;
	private boolean m_bInventory = false; // 是否盘存中
	private byte m_iInventoryMode = 0;	//盘存模式

	private Handler msgHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			String str = msg.getData().getString("msg");
			if ((null == str || 0 == str.length())
					&& ((UhfDev.MSG_TIMER != msg.what)
							&& (msg.what != UhfDev.MSG_PAUSE) && (msg.what != UhfDev.MSG_RESUME)))
				return;
			if (msg.what == UhfDev.MSG_EPC) { // 标签内容
				bSoundPlay = true;
				String epc = str;
				addToList(listEPC, epc);
			}// MSG_EPC
			else if (msg.what == UhfDev.MSG_OPEN) { // 连接
				setButtonClickable(buttonStart, true);
			} else if (msg.what == UhfDev.MSG_TIMER) { // 定时器
				Date dtNow = new Date(System.currentTimeMillis());
				long diff = dtNow.getTime() - dtStart.getTime();
				textViewReadTimeNum.setText(diff + "ms");
			} else if (msg.what == UhfDev.MSG_PAUSE) { // 暂停
				StopInventory();
			} else if (msg.what == UhfDev.MSG_RESUME) { // 继续
				StartInventory();
			} else { // 消息
				//textViewLog.setText(str);
			}
		}
	};

	// 设置匹配
	private boolean SetFilter() {
		String szEPC = "";
		byte epcLen = (byte) (szEPC.length() / 2);
		byte[] bEPC = new byte[epcLen];

		mDev.reader.Str2HexArray(szEPC, szEPC.length(), bEPC);
		byte bFilterBank = (byte) 0; // 0-not filter
										// 1-EPC;
		short startBits = 32;
		short maskBits = (short) (epcLen * 8);
		boolean bSucc = mDev.reader.SetFilter(bFilterBank, startBits, maskBits,
				bEPC, epcLen);
		Toast.makeText(this, getString(R.string.setFilter)+(bSucc ? getString(R.string.succ):getString(R.string.fail)), 
				Toast.LENGTH_SHORT).show();
		return bSucc;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_inventory);
		buttonStart = (Button) findViewById(R.id.buttonStart);
		buttonReset = (Button) findViewById(R.id.buttonReset);
		listViewData = (ListView) findViewById(R.id.listView_data);
		textViewSuccReadNum = (TextView) findViewById(R.id.textViewSuccReadNum);
		textViewTagReadNum = (TextView) findViewById(R.id.textViewTagReadNum);
		textViewReadTimeNum = (TextView) findViewById(R.id.textViewReadTimeNum);
		cbBackTag = (CheckBox) findViewById(R.id.checkBoxBack);
		cbBackTag.setOnCheckedChangeListener(this);
		buttonStart.setOnClickListener(this);
		buttonReset.setOnClickListener(this);
		setButtonClickable(buttonStart, true);

		listEPC = new ArrayList<EPC>();
		listViewData.setOnItemClickListener(this);
		mDev.SetHandleFunc(msgHandler);// 设置回调函数
		mDev.SetInvCallback(mInvCallback);
		StartSoundThread(); // 启动声音线程

		String szInventoryMode = getIntent().getStringExtra("InventoryMode");
		m_iInventoryMode = Byte.parseByte(szInventoryMode);
		SetInvMode(m_iInventoryMode, (byte) 0);

		DataManage.getInstance().StartSaveThread(InventoryActivity.this);
		PowerMoniter.getInstance().SetScreenPorait(this);// 禁止锁屏
		SetFilter();

	}// onCreate

    @Override
    protected void onPause() {
        super.onPause();
    }
	@Override
	protected void onDestroy() {
		super.onDestroy();
		
		DataManage.getInstance().StopSaveThread();
	}
	@Override
	public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
		if(cbBackTag.getId()==arg0.getId())
			SetInvMode(m_iInventoryMode,(byte)(arg1?1:0));
	}
	private InvCallBack mInvCallback = new InvCallBack() {
		public String HexToString(byte[] bArray) {
			StringBuffer sb = new StringBuffer(bArray.length);
			String sTemp;
			for (int i = 0; i < bArray.length; i++) {
				sTemp = Integer.toHexString(0xFF & bArray[i]);
				if (sTemp.length() < 2)
					sb.append(0);
				sb.append(sTemp.toUpperCase());
			}
			return sb.toString();
		}

		private void SendMsg(String EpcID) {
			Message msg = new Message();
			msg.what = UhfDev.MSG_EPC;
			Bundle bundle = new Bundle();
			bundle.putString("msg", EpcID); // 往Bundle中存放数据
			msg.setData(bundle); // mes利用Bundle传递数据
			msgHandler.sendMessage(msg);// 用activity中的handler发送消息
		}

		@Override
		public void execute(List<TAGINFO> lstTagInfo) {
			if (null == lstTagInfo || lstTagInfo.size() == 0)
				Log.e("Inventory", "错误内容");
			// 处理数据
			Hashtable<byte[], TAGINFO> htNewTagInfo = new Hashtable<byte[], TAGINFO>();
			String szTag = "";

			for (int i = 0; i < lstTagInfo.size(); i++) {
				TAGINFO tfs = lstTagInfo.get(i);
				if (null == tfs)
					continue;
				// 处理数据
				szTag = HexToString(tfs.EpcId) + ";" + tfs.ReadCnt + ";"
						+ tfs.RSSI;
				SendMsg(szTag);
			}
			Log.e("Inventory", "发送数据完毕");
		}
	};

	private void SetInvMode(byte iInventoryMode, byte flag) {
		 String[] tagNumArray = getResources().getStringArray(R.array.tagNum_array);
		 this.setTitle(tagNumArray[iInventoryMode]);
		boolean bSucc = mDev.SetReadMode(iInventoryMode, flag);
	}

	// 获取盘存按钮内容
	private String GetInvBtn(boolean bStart) {
		return bStart?getString(R.string.startInventory):getString(R.string.stopInventory);
	}

	// 将读取的EPC添加到LISTVIEW
	private void addToList(final List<EPC> listEPC, final String epcCount) {
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				String[] szInfo = epcCount.split(";");
				String epc = szInfo[0];
				int count = Integer.parseInt(szInfo[1]);
				int rssi = Integer.parseInt(szInfo[2]);

				int index = 0;
				for (index = 0; index < listEPC.size(); index++) {
					EPC mEPC = listEPC.get(index);
					// list中有此EPC
					if (epc.equals(mEPC.getEpc())) {
						int size = mEPC.getCount() + count;
						mEPC.setCount(size);
						listEPC.set(index, mEPC);

						Map<String, Object> map = listMap.get(index);
						map.put("COUNT", size);
						map.put("RSSI", rssi);
						listMap.set(index, map);
						break;
					}
				}

				if (index == listEPC.size()) {
					// list中没有此epc
					EPC newEPC = new EPC();
					newEPC.setId(index);
					newEPC.setEpc(epc);
					newEPC.setCount(count);
					newEPC.setRSSI(rssi);
					listEPC.add(newEPC);

					Map<String, Object> map = new HashMap<String, Object>();
					map.put("ID", index);
					map.put("EPC", epc);
					map.put("COUNT", count);
					map.put("RSSI", rssi);
					listMap.add(map);
					
					DataManage.getInstance().AddOneAssetsInfo(newEPC);   //实时保存数据
				}

				succSum += count;

				tagSum = listEPC.size();
				textViewSuccReadNum.setText("" + succSum);
				textViewTagReadNum.setText("" + tagSum);

				listViewData.setAdapter(new SimpleAdapter(
						InventoryActivity.this, listMap,
						R.layout.listview_item, new String[] { "ID", "EPC",
								"COUNT", "RSSI" }, new int[] {
								R.id.textView_id, R.id.textView_epc,
								R.id.textView_count, R.id.textView_rssi }));
			}// run end
		});
	}

	// 设置按钮是否可用
	private void setButtonClickable(Button button, boolean flag) {
		button.setClickable(flag);
		if (flag) {
			button.setTextColor(Color.BLACK);
		} else {
			button.setTextColor(Color.GRAY);
		}
	}

	private void SetScreenOn(boolean bOn) {
		if (bOn)
			PowerMoniter.getInstance().acquireWakeLock(this);
		else
			PowerMoniter.getInstance().releaseWakeLock();
	}

	/**
	 * 清空listview
	 */
	private void clearData() {
		listEPC.clear();
		listMap.clear();
		// listEPC.removeAll(listEPC);
		listViewData.setAdapter(null);
		succSum = 0;
		tagSum = 0;
		textViewSuccReadNum.setText("" + succSum);
		textViewTagReadNum.setText("" + tagSum);
		textViewReadTimeNum.setText("");
		dtStart = new Date(System.currentTimeMillis());
	}

	// 开始盘存
	private void StartInventory() {
		if (m_bInventory)
			return;
		SetScreenOn(true);
		m_bInventory = true;
		mDev.inventory();
		buttonStart.setText(GetInvBtn(false));
		dtStart = new Date(System.currentTimeMillis());
		handler.postDelayed(runnableTimer, 200);// 每X秒执行一次runnable.
		//this.setButtonClickable(cbBackTag, false);
	}

	// 停止盘存
	public void StopInventory() {
		m_bInventory = false;
		handler.removeCallbacks(runnableTimer);
		// timer.cancel();
		mDev.pause();
		buttonStart.setText(GetInvBtn(true));
		SetScreenOn(false);
		//this.setButtonClickable(cbBackTag, true);
	}

	@SuppressLint("SimpleDateFormat")
	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.buttonStart:
			SoundUtil.play(R.raw.pegconn, 0);
			if (buttonStart.getText().equals(GetInvBtn(true))) {
				StartInventory();
			} else {
				StopInventory();
			}
			break;
		case R.id.buttonReset:
			SoundUtil.play(R.raw.pegconn, 0);
			clearData();
			break;
		default:
			break;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position,
			long id) {
		if (adapter.getId() == listViewData.getId()) {
			if (id == -1)
				return;

			mDev.pause();

			int realPosition = (int) id;
			Map<String, Object> map = listMap.get(realPosition);
			String szEPC = (String) map.get("EPC");
			Intent localIntent = new Intent(this, InventoryFilter.class);
			localIntent.putExtra("EPCDate", szEPC);
			startActivityForResult(localIntent, 0);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (0 == requestCode) { // resultCode为回传的标记，我在B中回传的是RESULT_OK
		}
	}

	// region 声音线程
	private Thread thSound = null; // 声音线程句柄
	private boolean runSoundTh = false; // 声音线程开关
	private boolean bSoundPlay = false; // 声音
	private SoundPool soundPool = null;

	// 启动声音线程
	private void StartSoundThread() {
		if (null == thSound) {
			runSoundTh = true;
			thSound = new Thread(SoundThread);
			thSound.start();
		}
		soundPool = new SoundPool(10, AudioManager.STREAM_SYSTEM, 5);// AudioManager.STREAM_SYSTEM
		soundPool.load(this, R.raw.beep51, 1);// chimes
	}

	// 停止声音线程
	private void StopSoundThread() {

		try {
			if (null != thSound) {
				bSoundPlay = false;
				runSoundTh = false;
				thSound.join(2000);
				thSound.interrupt();
				thSound = null;
				soundPool.release();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void Sleep(int time) {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	Runnable SoundThread = new Runnable() {
		@Override
		public void run() {
			int iSoundTimes = 0;
			while (runSoundTh) {
				try {
					if (bSoundPlay) { // 响两次
						bSoundPlay = false;
						iSoundTimes = 6;
					}
					if (iSoundTimes > 0) {
						soundPool.play(1, 1, 1, 0, 0, 1);
						// SoundUtil.play(R.raw.c himes, 0);
						iSoundTimes--;
					}
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	};
	// endregion

	Handler handler = new Handler();
	Runnable runnableTimer = new Runnable() {
		@Override
		public void run() {
			// TODO Auto-generated method stub
			// 要做的事情
			handler.postDelayed(this, 200);
			Message message = new Message();
			message.what = UhfDev.MSG_TIMER;
			msgHandler.sendMessage(message);
		}
	};

	// endregion

	// region 按键事件
	/* 键按下事件 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((134 == keyCode)||(275==keyCode))
			StartInventory();
		return super.onKeyDown(keyCode, event);
	}

	/* 释放按键事件 */
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		if ((134 == keyCode)||(275==keyCode))
			StopInventory();
		else if (keyCode == KeyEvent.KEYCODE_BACK) {			
			StopInventory();
			StopSoundThread(); // 停止声音线程
			finish();
			return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	// endregion

}
