package com.demo.moduleapidemo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EPC {
	private int id;
	private String epc;
	private int count;
	private int rssi;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the epc
	 */
	public String getEpc() {
		return epc;
	}

	/**
	 * @param epc
	 *            the epc to set
	 */
	public void setEpc(String epc) {
		this.epc = epc;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count
	 *            the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	public void setRSSI(int rssi) {
		this.rssi = rssi;
	}

	public static String getHeaderString() {
		return "Time,EPC,RSSI\r\n";
	}

	public String getValueString() {
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
        Date curDate = new Date(System.currentTimeMillis());//获取当前时间
		return formatter.format(curDate) + "," + epc + ","  + rssi + "\r\n";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EPC [id=" + id + ", epc=" + epc + ", count=" + count
				+ ", rssi=" + rssi + "]";
	}

}
