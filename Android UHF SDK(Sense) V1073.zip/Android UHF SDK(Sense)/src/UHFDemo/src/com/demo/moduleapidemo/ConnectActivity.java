//ConnectActivity.java：连接页面
package com.demo.moduleapidemo;

import java.net.InetSocketAddress;
import com.demo.utils.UhfDev;
import com.function.DemoConfig;

import com.wifi.ibase.*;
import com.wifi.udpserver.*;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.content.Intent;

public class ConnectActivity extends Activity {

	private TextView mConnectReader, mCancel;
	private RadioButton mRdA10, mRdH7;
	private UhfDev mDev = UhfDev.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_connect);

		mConnectReader = (TextView) findViewById(R.id.textview_connect_reader);
		mCancel = (TextView) findViewById(R.id.textview_cancel);
		mRdA10 = (RadioButton) findViewById(R.id.radio_connect_a10);
		mRdH7 = (RadioButton) findViewById(R.id.radio_connect_h7);

		mConnectReader.setOnClickListener(setConnectOnClickListener);
		mCancel.setOnClickListener(setConnectOnClickListener);
		mRdA10.setOnCheckedChangeListener(setConnectType);
		mRdH7.setOnCheckedChangeListener(setConnectType);

		mRdH7.setChecked(true);
		initTcp();
		SetModType();
	}

	// 显示&隐藏tcp参数
	private void ShowTcpVisible(boolean bVisible) {
		LinearLayout ll = (LinearLayout) findViewById(R.id.ll_tcp_para);
		LinearLayout ll2 = (LinearLayout) findViewById(R.id.ll_tcp_para2);
		ll.setVisibility(bVisible ? View.VISIBLE : View.INVISIBLE);
		ll2.setVisibility(bVisible ? View.VISIBLE : View.INVISIBLE);
	}

	// 获取服务器IP
	private String GetServerIP() {
		String host = mConectTcpIpAddress.getText().toString();
		if (host == null || host.length() <= 0) {
			Toast.makeText(getApplicationContext(), getString(R.string.InvalidIP),
					Toast.LENGTH_SHORT).show();
			return "";
		}
		return host;
	}

	// 获取服务器端口号
	private int GetServerPort() {
		String strPort = mConectTcpIpPort.getText().toString();
		if (strPort == null || strPort.length() <= 0) {
			Toast.makeText(getApplicationContext(), getString(R.string.InvalidPort),
					Toast.LENGTH_SHORT).show();
			return 0;
		}
		int port = Integer.parseInt(strPort);
		return port;
	}

	// 查询型号
	private int GetModType() {
		int iModType = 0;
		if (mRdA10.isChecked()) // A10
			iModType = 1;
		else if (mRdH7.isChecked())
			iModType = 2;
		return iModType;
	}

	//配置型号
	private void SetModType() {
		switch(DemoConfig.getInstance().iUHFModType) {
		case 1:
			mRdA10.setChecked(true);
			break;
			default:
				mRdH7.setChecked(true);
				break;
		}
	}
	
	//保存型号
	private void SaveConfig() {
		DemoConfig.getInstance().iUHFModType = GetModType();
		DemoConfig.getInstance().ServerIP = GetServerIP();
		DemoConfig.getInstance().ServerPort =""+ GetServerPort();
		DemoConfig.getInstance().SaveConfig();
	}
	// 连接读写器
	private void ConnectReader() {
		int iModType = GetModType();
		if (!mDev.InitDevice(iModType)) {
			Toast.makeText(getApplicationContext(), getString(R.string.InitFailed), Toast.LENGTH_SHORT)
					.show();
			return;
		}
		if (2 != iModType) {
			if (!mDev.Open()) {
				Toast.makeText(getApplicationContext(), getString(R.string.ConnectFailed),
						Toast.LENGTH_SHORT).show();
				return;
			}
		} else {
			String IP = GetServerIP();
			if ("" == IP) {
				Toast.makeText(getApplicationContext(), getString(R.string.InvalidIP),
						Toast.LENGTH_SHORT).show();
				return;
			}
			int port = GetServerPort();
			if (0 == port) {
				Toast.makeText(getApplicationContext(), getString(R.string.InvalidPort),
						Toast.LENGTH_SHORT).show();
				return;
			}
			if (!mDev.OpenByTcp(IP, port)) {
				Toast.makeText(getApplicationContext(), getString(R.string.ConnectFailed),
						Toast.LENGTH_SHORT).show();
				return;
			}
		}
		Log.d("Inventory", "iModType=" + iModType);
		SaveConfig();
		Intent localIntent = new Intent(this, MainActivity.class);
		localIntent.putExtra("ModType", iModType);
		startActivity(localIntent);
		finish();
	}

	private OnCheckedChangeListener setConnectType = new OnCheckedChangeListener() {
		@Override
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			if (!isChecked)
				return;
			switch (buttonView.getId()) {
			case R.id.radio_connect_a10:
				ShowTcpVisible(false);
				break;
			case R.id.radio_connect_h7:
				ShowTcpVisible(true);
				break;
			default:
				break;
			}
		};
	};

	private OnClickListener setConnectOnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.textview_connect_reader:
				ConnectReader();
				break;
			case R.id.textview_cancel:
				android.os.Process.killProcess(android.os.Process.myPid()); // 杀死该进程
				System.exit(0); // 退出
				finish();
				break;
			default:
				break;
			}
		};
	};

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	// region TCP连接
	private static final String HOSTNAME_REGEXP = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\."
			+ "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
			+ "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
			+ "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";
	private EditText mConectTcpIpAddress;
	private EditText mConectTcpIpPort;
	private TextView mConectButton;
	private Button mScanIPButton = null;

	private static final int CONNECTING = 0x10;
	private static final int CONNECT_TIMEOUT = 0x100;
	private static final int CONNECT_FAIL = 0x101;
	private static final int CONNECT_SUCCESS = 0x102;

	InetSocketAddress mRemoteAddr;

	private void initTcp() {
		mConectTcpIpAddress = (EditText) findViewById(R.id.connect_tcp_ip_address_text);
		mConectTcpIpPort = (EditText) findViewById(R.id.connect_tcp_ip_port_text);
		mConectButton = (TextView) findViewById(R.id.textview_connect_reader);
		mScanIPButton = (Button) findViewById(R.id.but_scanhandle);
		
		mConectTcpIpAddress.setText(DemoConfig.getInstance().ServerIP);
		mConectTcpIpPort.setText(DemoConfig.getInstance().ServerPort);
		
		TUdpManage.getInstance().SetContext(ConnectActivity.this);
		TUdpManage.getInstance().mWifiInfoBack = mCallback;
		
		mScanIPButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				com.wifi.utils.FindDeviceIP find = new com.wifi.utils.FindDeviceIP();
				find.sendUdpCommand(ConnectActivity.this, msgHandler);

				TUdpManage.getInstance().ScanWifiMod();
			}
		});

		mScanIPButton.performClick();
	}

	private Handler msgHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			String str = msg.getData().getString("msg");
			if (msg.what == com.wifi.utils.FindDeviceIP.IS_DEVICE_IP) { // 内容
				String szIP = msg.getData().getString("ip");
				mConectTcpIpAddress.setText(szIP);
			} else if (msg.what == 2) {
				WifiModInfo wifiInfo = (WifiModInfo) msg.obj;
				mConectTcpIpAddress.setText(wifiInfo.IP);
				mConectTcpIpPort.setText(""+wifiInfo.ServerPort);
			}
		}
	};
	// H7 Wifi
	// 回调方式
	private ICallbackWifiInfo mCallback = new ICallbackWifiInfo() {
		@Override
		public void execute(WifiModInfo wifiInfo) {
			Message msg = new Message();
			msg.what = 2;
			msg.obj = wifiInfo;
			msgHandler.sendMessage(msg);
		}
	};

	/*
	 * 
	 * private Handler msgHandler = new Handler() {
	 * 
	 * @Override public void handleMessage(Message msg) { String str =
	 * msg.getData().getString("msg"); if (msg.what ==
	 * com.RFID.FindDeviceIP.IS_DEVICE_IP) { // 内容 String szIP =
	 * msg.getData().getString("ip"); mConectTcpIpAddress.setText(szIP); } } };
	 */

	private final Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			Intent intent = null;
			switch (msg.what) {
			case CONNECTING:
				Toast.makeText(getApplicationContext(),getString(R.string.Connecting) ,
						Toast.LENGTH_SHORT).show();
				break;
			case CONNECT_TIMEOUT:
				Toast.makeText(getApplicationContext(), getString(R.string.ConnectTimeout),
						Toast.LENGTH_SHORT).show();
				break;
			case CONNECT_FAIL:
				Toast.makeText(getApplicationContext(), getString(R.string.ConnectFailed),
						Toast.LENGTH_SHORT).show();
				break;
			case CONNECT_SUCCESS:
				Toast.makeText(getApplicationContext(), getString(R.string.ConnectFailed),
						Toast.LENGTH_SHORT).show();
				
				SaveConfig();
				intent = new Intent().setClass(ConnectActivity.this,
						MainActivity.class);
				startActivity(intent);
				finish();
				break;
			}
		}
	};
	// endregion
}
