//MainActivity.java: 功能页面
package com.demo.moduleapidemo;

import com.demo.utils.SoundUtil;
import com.demo.utils.UhfDev;
import com.function.MyReceiver;

import android.Manifest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {
	private Button mInventoryButton,btnMultiInventory;
	private Button mSearchButton;
	private Button mAboutButton;
	private Button mAccessButton;
	private Button mSettingButton;
	private UhfDev mDev = UhfDev.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		SoundUtil.initSoundPool(this);
		this.mInventoryButton = ((Button) findViewById(R.id.btnInventory));
		this.btnMultiInventory = (Button)findViewById(R.id.btnMultiInventory);
		this.mSearchButton = ((Button) findViewById(R.id.btnSearch));
		this.mAboutButton = ((Button) findViewById(R.id.btnAbout));
		this.mAccessButton = ((Button) findViewById(R.id.btnAccess));
		this.mSettingButton = ((Button) findViewById(R.id.btnSetting));
		this.mInventoryButton.setOnClickListener(this);
		this.btnMultiInventory.setOnClickListener(this);
		this.mSearchButton.setOnClickListener(this);
		this.mAboutButton.setOnClickListener(this);
		this.mAccessButton.setOnClickListener(this);
		this.mSettingButton.setOnClickListener(this);

		mDev.StartDev(msgHandler);
		MyReceiver.getInstance().StartMoniter(this);
		SetTitleVers();	//设置版本信息
		
//		requertPhonePermission(); 
	}
//	
//    @TargetApi(23) private void requertPhonePermission() {
////        // 检查系统版本
////        if (Build.VERSION.SDK_INT >= 23) {
////            // 相机权限
////            int checkCallCameraPermission = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA);
////            if (checkCallCameraPermission != PackageManager.PERMISSION_GRANTED) {
////                requestPermissions(new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, 121);
////            }
////        }    	
//    	String[] perms = {"Manifest.permission.WRITE_EXTERNAL_STORAGE"};
//    	int permsRequestCode = 200; 
//    	requestPermissions(perms, permsRequestCode);
//    }
//        // 权限检测反馈
//        @TargetApi(23) @Override 
//    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (grantResults.length > 0) {
//            int count = 0;
//            for (int grantResult : grantResults) {
//                if (grantResult != PackageManager.PERMISSION_GRANTED) {
//                    count++; 
//                }
//            }
//            if (count != 0) {
//                Toast.makeText(this, "授权拒绝", Toast.LENGTH_LONG).show();
//           } else {
//               Toast.makeText(this, "授权成功", Toast.LENGTH_LONG).show();
//                        }
//        }
//    }
	//设置版本信息
	private void SetTitleVers() {
		String szValue = getResources().getString(R.string.app_name_vers);
		this.setTitle(szValue);
	}
	

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	private Handler msgHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			String str = msg.getData().getString("msg");
			if (UhfDev.MSG_OPEN == msg.what) {
				SetBtnStatus(true);
				Toast.makeText(MainActivity.this, str, Toast.LENGTH_SHORT).show();
			} else if (UhfDev.MSG_INFO == msg.what) {
				Toast.makeText(MainActivity.this, str, Toast.LENGTH_SHORT).show();
			}
		}
	};

	private void SetBtnStatus(boolean bEnabled) {
		setButtonClickable(mInventoryButton, bEnabled);
		setButtonClickable(btnMultiInventory, bEnabled);
		setButtonClickable(mSearchButton, bEnabled);
		setButtonClickable(mAccessButton, bEnabled);
		setButtonClickable(mSettingButton, bEnabled);
		setButtonClickable(mAboutButton, true);
	}

	// 设置按钮是否可用
	private void setButtonClickable(Button button, boolean flag) {
		button.setClickable(flag);
		button.setTextColor(flag ? Color.BLACK : Color.GRAY);
	}

	private void ExitApp() {
		MyReceiver.getInstance().StopMoniter(this);
		mDev.Close();
		SoundUtil.releaseSoundPool();
		android.os.Process.killProcess(android.os.Process.myPid()); //释放进程
        System.exit(0); //退出
	}
	
	/* 释放按键事件 */
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			ExitApp();
			return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		Intent localIntent;
		SoundUtil.play(R.raw.pegconn, 0);
		switch (arg0.getId()) {
		case R.id.btnMultiInventory: //大量标签盘存
			localIntent = new Intent(this, InventoryActivity.class);
			localIntent.putExtra("InventoryMode", "3");
			localIntent.putExtra("title", "Inventory");
			startActivity(localIntent);
			break;
		case R.id.btnInventory:	//盘存模式
			localIntent = new Intent(this, InventoryActivity.class);
			localIntent.putExtra("InventoryMode", "1");
			localIntent.putExtra("title", "Inventory");
			startActivity(localIntent);
			break;
		case R.id.btnSearch:	//省电模式
			localIntent = new Intent(this, InventoryActivity.class);
			localIntent.putExtra("InventoryMode", "0");
			localIntent.putExtra("title", "Inventory");
			startActivity(localIntent);
			break;
		case R.id.btnAccess: //标签读写
			localIntent = new Intent(this, ReaderAccess.class);
			localIntent.putExtra("title", "Access");
			startActivity(localIntent);
			break;
		case R.id.btnSetting:	//配置页面
			localIntent = new Intent(this, ReaderConfig.class);
			localIntent.putExtra("title", "Setting");
			startActivity(localIntent);
			break;
		case R.id.btnAbout:
			ExitApp();
			this.finish();
			break;
		default:
			break;
		}
	}

}
