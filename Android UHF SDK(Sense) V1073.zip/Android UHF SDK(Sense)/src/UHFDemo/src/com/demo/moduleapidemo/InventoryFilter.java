//ReaderAccess.java：标签读写页面
package com.demo.moduleapidemo;

import com.demo.utils.UhfDev;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class InventoryFilter extends Activity implements View.OnClickListener {
	Button button_setmask, button_getmask;
	String[] spibank = { "NoFilter", "EPC", "TID", "User", };// 运行时添加
	EditText etEPC;
	CheckBox cbEPC;
	UhfDev m_UHFDev = UhfDev.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.inventory_filter);
		super.onCreate(savedInstanceState);
		initView();
	}

	private void initView() {
		// 选项
		etEPC = (EditText) findViewById(R.id.editText_EPC);
		cbEPC = (CheckBox) findViewById(R.id.cbEPC);
		cbEPC.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				etEPC.setVisibility(cbEPC.isChecked() ? View.VISIBLE
						: View.INVISIBLE);
				// etEPC.setEnabled(!cbEPC.isChecked());
				// SetAccessEPCMask();
			}
		});

		// 按钮
		button_getmask = (Button) findViewById(R.id.button_getmask);
		button_setmask = (Button) findViewById(R.id.button_setmask);
		button_getmask.setOnClickListener(this);
		button_setmask.setOnClickListener(this);

		String szInvEPCDate = getIntent().getStringExtra("EPCDate");
		if (null != szInvEPCDate && szInvEPCDate.length() > 0)
			etEPC.setText(szInvEPCDate);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	// 设置匹配
	private boolean SetFilter() {
		String szEPC = etEPC.getText().toString().replace(" ", "");
		byte epcLen = (byte) (szEPC.length() / 2);
		byte[] bEPC = new byte[epcLen];

		m_UHFDev.reader.Str2HexArray(szEPC, szEPC.length(), bEPC);
		byte bFilterBank = (byte) (cbEPC.isChecked() ? 1 : 0); // 0-not filter
																// 1-EPC;
		short startBits = 32;
		short maskBits = (short) (epcLen * 8);
		boolean bSucc = m_UHFDev.reader.SetFilter(bFilterBank, startBits,
				maskBits, bEPC, epcLen);
		Toast.makeText(InventoryFilter.this,getString(R.string.setFilter)+
				(bSucc ?getString(R.string.succ):getString(R.string.fail)),
				Toast.LENGTH_SHORT).show();
		return bSucc;
	}

	// 查询匹配
	private boolean GetAccessMask() {
		etEPC.setText("");
		byte[] bMode = new byte[2];
		byte[] bEPCLen = new byte[2];
		byte[] bEPC = new byte[0xFF];
		byte []bFilterBank = new byte[2]; 
		short []startBits = new short[2]; 
		short []maskBits = new short[2]; 
		byte[] pFilterData = new byte[60]; 
		byte []filterDataLen = new byte[2]; 
		boolean bSucc = m_UHFDev.reader.GetFilter(bFilterBank, startBits, maskBits, 
				pFilterData, filterDataLen);
		if (!bSucc) {
			Toast.makeText(InventoryFilter.this, getString(R.string.getFilter)
					+getString(R.string.fail), Toast.LENGTH_SHORT)
					.show();
			return false;
		}
		cbEPC.setChecked(bFilterBank[0]>=0);
		String szEPC = m_UHFDev.reader.HexArray2Str(pFilterData, filterDataLen[0]);
		etEPC.setText(szEPC);
		Toast.makeText(InventoryFilter.this,getString(R.string.getFilter)
				+getString(R.string.succ), Toast.LENGTH_SHORT)
				.show();
		return true;
	}

	@Override
	public void onClick(View v) {
		try {
			switch (v.getId()) {
			case R.id.button_getmask: // 查询匹配
				GetAccessMask();
				break;
			case R.id.button_setmask: // 盘存标签
				SetFilter();
				break;
			default:
				break;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(InventoryFilter.this, getString(R.string.fail)+": "+ e.getMessage(),
					Toast.LENGTH_SHORT).show();
		}
	}
}
