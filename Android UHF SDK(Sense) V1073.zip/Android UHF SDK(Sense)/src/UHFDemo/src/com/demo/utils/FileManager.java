package com.demo.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import java.io.File;

/**
 * Created by Administrator on 2016/11/25.
 */
public class FileManager {

	// 生成文件
	public static File makeFilePath(String filePath, String fileName) {
		File file = null;
		makeDirectory(filePath);
		try {
			file = new File(fileName);
			if (!file.exists()) {
				file.createNewFile();
				Process p = Runtime.getRuntime().exec("chmod 777 " + fileName);
				int status = p.waitFor();
				if (status == 0) {
					// chmod succeed
				} else {
					// chmod failed
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return file;
	}

	// 生成文件夹
	public static void makeDirectory(String filePath) {
		File file = null;
		try {
			file = new File(filePath);
			if (!file.exists()) {
				file.mkdirs();

				Process p = Runtime.getRuntime().exec("chmod 777 " + filePath);
				int status = p.waitFor();
				if (status == 0) {
					// chmod succeed
				} else {
					// chmod failed
				}
			}
		} catch (Exception e) {
			Log.i("error:", e + "");
		}
	}

	// 扫描文件，放置文件无法在PC上查
	public static void fileScan(Context context, String filePath) {
		Uri data = Uri.parse("file://" + filePath);
		context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
				data));
	}
}
