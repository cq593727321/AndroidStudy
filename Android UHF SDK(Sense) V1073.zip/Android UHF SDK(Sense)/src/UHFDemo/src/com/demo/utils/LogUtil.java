package com.demo.utils;

import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogUtil
{
  public static final boolean DEBUG = true;
  public static final boolean IS_SAVE_LOG = false;
  public static final String filePath = "mnt/sdcard/MouduleAPIDemoLog.txt";

  public static void d(String paramString1, String paramString2)
  {
    Log.d(paramString1, paramString2);
  }

  public static void e(String paramString1, String paramString2)
  {
    Log.e(paramString1, paramString2);
  }

  public static void exception(Throwable paramThrowable)
  {
    outputToFile(formatThrowable(paramThrowable.getStackTrace()));
  }

  private static String formatStackTraceElement(StackTraceElement paramStackTraceElement)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(paramStackTraceElement.getFileName());
    localStringBuffer.append(".");
    localStringBuffer.append(paramStackTraceElement.getMethodName());
    localStringBuffer.append("().(");
    localStringBuffer.append(paramStackTraceElement.getLineNumber());
    localStringBuffer.append(")");
    return localStringBuffer.toString();
  }

  public static String formatThrowable(StackTraceElement[] paramArrayOfStackTraceElement)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfStackTraceElement.length)
        return localStringBuffer.toString();
      localStringBuffer.append("  ");
      localStringBuffer.append(formatStackTraceElement(paramArrayOfStackTraceElement[i]));
      localStringBuffer.append("\n");
    }
  }

  private static String getCurrentTime()
  {
    long l = System.currentTimeMillis();
    return new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date(l));
  }

  public static void i(String paramString1, String paramString2)
  {
    Log.i(paramString1, paramString2);
  }

  public static void l()
  {
    Log.e("", formatStackTraceElement(Thread.currentThread().getStackTrace()[3]) + "--->>");
  }

  public static void l(int paramInt)
  {
    l(paramInt);
  }

  public static void l(String paramString)
  {
    Log.e("", formatStackTraceElement(Thread.currentThread().getStackTrace()[4]) + "--->>" + paramString);
  }

  public static void l(byte[] paramArrayOfByte)
  {
    StackTraceElement[] arrayOfStackTraceElement = Thread.currentThread().getStackTrace();
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfByte.length)
      {
        Log.e("", formatStackTraceElement(arrayOfStackTraceElement[3]) + "--->>" + localStringBuffer);
        return;
      }
      localStringBuffer.append(paramArrayOfByte[i]);
      localStringBuffer.append("-");
    }
  }

  public static void outputToFile(String paramString)
  {
  }

  public static void v(String paramString1, String paramString2)
  {
    Log.v(paramString1, paramString2);
  }

  public static void w(String paramString1, String paramString2)
  {
    Log.w(paramString1, paramString2);
  }

  public void logStack()
  {
    outputToFile(formatThrowable(Thread.currentThread().getStackTrace()));
  }
}

